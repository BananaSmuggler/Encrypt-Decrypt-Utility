
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.File;

public class Cipher {

    public static void main(String[] args) {
        Cipher.welcomeMenu();
    }

        private static void welcomeMenu() {
            Scanner kb = new Scanner(System.in);

            String welcomeMenu = "Welcome to My Encryption/Decryption Program\n" +
                                 "Please enter the letter of your chosen operation:\n" +
                                 "\ta) Encrypt a message\n" +
                                 "\tb) Decrypt a message\n" +
                                 "\tc) Exit\n" +
                                 "Enter option: ";
            String invalid = "Invalid choice, please try again!";
            String inputMessage = "Inpput your message: ";
            String inputPassword = "Input password (must be greater than 8 character): ";
            String inputFileName = "Enter filename: ";
            char optionInput;

            System.out.print(welcomeMenu);
            optionInput = kb.next().toLowerCase().charAt(0);

            while (optionInput != 'a' && optionInput != 'b' && optionInput != 'c') {
                System.out.println("\n" + invalid + "\n\n" + welcomeMenu);
                optionInput = kb.next().toLowerCase().charAt(0);
            }

            kb.nextLine();
            if (optionInput == 'a' || optionInput == 'A') {
                System.out.print(inputMessage);
                String message = kb.nextLine();
                String password = getValidPassword(kb, inputPassword);
                System.out.print(inputFileName);
                String fileName = kb.nextLine();
                @SuppressWarnings("unused")
				String cipherText = encrypt(message, password, fileName);
            }

            else if (optionInput == 'b' || optionInput == 'B') {
                String password = getValidPassword(kb, inputPassword);
                System.out.print(inputFileName);
                String fileName = kb.nextLine();
                String cipherText = readMessageFromFile(fileName);
                String message = decrypt(cipherText, password);
                System.out.println(message);
            }

            else if (optionInput == 'c' || optionInput == 'C') {
                System.out.println("Thank you, have a nice day.");
            }
        }

        private static String encrypt(String message, String password, String fileName) {
            char[] message_char = new char[message.length()];
            for (int i=0; i < message.length(); i++) {
                message_char[i] = message.charAt(i);
            }

            String cipherText = "0x";
            String hex = "";

            char[] cipher_char = new char[message.length()];
            for (int i=0; i < message.length(); i++) {
                cipher_char[i] = (char)((int)(message_char[i]) ^ ((int)(getPasswordCharacter(password, i))));

                    if (Integer.toHexString((cipher_char[i])).toString().length() != 2) {
                        hex += Integer.toHexString((cipher_char[i]));
                    } else {
                        hex += Integer.toHexString((cipher_char[i]));
                    }
            }
            cipherText = cipherText + hex;
            writeMessageToFile(fileName, cipherText);
            return cipherText;
        }

        private static String decrypt(String cipherText, String password) {
            String message = "";
            int[] twoDigitsArray = new int[(cipherText.length()-2) / 2];

            for (int i=0; i <twoDigitsArray.length; i++) {
                twoDigitsArray[i] = Integer.parseInt(cipherText.substring((i+1)*2, ((i+1)*2)+2), 16);
                message += (char)((twoDigitsArray[i]) ^ (int)(password.charAt(i % password.length())));
            }
            return message;
        }

        private static char getPasswordCharacter(String password, int index) {
            return password.charAt(index % password.length());
        }

        private static String getValidPassword(Scanner kb, String inputPassword) {
            System.out.print(inputPassword);
            String password = kb.nextLine();

            while (password.length() <= 8) {
                System.out.println("\n" + "Invalid password length! Please try again or press crtl->c to quit." + "\n");
                System.out.print(inputPassword);
                password = kb.nextLine();
            }
            return password;
        }

        private static void writeMessageToFile(String fileName, String cipherText) {
            try {
                PrintWriter writer = new PrintWriter(fileName);
                writer.print(cipherText);
                writer.close();
            } catch (FileNotFoundException e) {
                System.out.println("There was an error writing to the file.");
            }
        }

        private static String readMessageFromFile(String fileName) {
            File file = new File(fileName);
            try {
                Scanner scanner = new Scanner(file);
                String cipherText = scanner.nextLine();
                scanner.close();
                return cipherText;
            } catch (FileNotFoundException e) {
                System.out.println("There was an error reading from the file.");
            }
            return null;
        }
}


























